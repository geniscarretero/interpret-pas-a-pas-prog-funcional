module HSTipus where

data Expr = Val Int                 -- Un número (42)
          | Var String              -- Una variable (x, y, suma, not, +, *)
          | App Expr Expr           -- Aplicació de funció (f x)
          | Lam String Expr       -- Funció lambda (\x -> x + 1)
          deriving (Show)

data Tipus = TInt
           | TBool
           | TFun Tipus Tipus
           | TVar String
           deriving (Show)

showTipus :: Tipus -> String
showTipus TInt = "Int"
showTipus TBool = "Bool"
showTipus (TFun (TFun t1 t2) t3) = "(" ++ showTipus t1 ++ " -> " ++ showTipus t2 ++ ")" ++ " -> " ++ showTipus t3 
showTipus (TFun t1 t2) = showTipus t1 ++ " -> " ++ showTipus t2
showTipus (TVar a) = a
